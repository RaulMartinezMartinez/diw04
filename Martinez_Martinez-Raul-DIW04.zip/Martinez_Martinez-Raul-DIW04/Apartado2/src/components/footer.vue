<template>
    <footer id="pie">
    <p>© Copyright 2022 LUCKYBIKE S.L - Todos los derechos reservados </p>
    </footer>
</template>

<script>
export default {

}
</script>

<style scoped>
    #pie{
        display: flex;
        padding: 3em;
        margin-top: 20px;
        background-color: rgba(0, 0, 0, 0.726);
        color: white;
        justify-content: center;
    }
</style>

